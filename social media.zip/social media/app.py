import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Page Configuration
st.set_page_config(page_title="Social Media Reach Analysis", layout="wide")

st.title("📊 Social Media Reach Analysis")

# Upload Dataset
uploaded_file = st.file_uploader("Upload CSV File", type=["csv"])

if uploaded_file is not None:

    df = pd.read_csv(uploaded_file)

    st.header("Dataset")
    st.dataframe(df)

    st.header("Dataset Information")

    col1, col2, col3 = st.columns(3)

    col1.metric("Rows", df.shape[0])
    col2.metric("Columns", df.shape[1])
    col3.metric("Missing Values", df.isnull().sum().sum())

    st.subheader("Statistical Summary")
    st.write(df.describe())

    st.subheader("Missing Values")
    st.write(df.isnull().sum())

    st.subheader("Correlation Heatmap")

    numeric_df = df.select_dtypes(include='number')

    fig, ax = plt.subplots(figsize=(8,6))
    sns.heatmap(numeric_df.corr(), annot=True, cmap="Blues", ax=ax)
    st.pyplot(fig)

    st.subheader("Reach Distribution")

    fig, ax = plt.subplots()
    sns.histplot(df["Reach"], bins=10, kde=True, ax=ax)
    st.pyplot(fig)

    st.subheader("Likes vs Reach")

    fig, ax = plt.subplots()
    sns.scatterplot(data=df, x="Likes", y="Reach", hue="Platform", ax=ax)
    st.pyplot(fig)

    st.subheader("Post Type Distribution")

    fig, ax = plt.subplots()
    sns.countplot(data=df, x="Post_Type", ax=ax)
    plt.xticks(rotation=45)
    st.pyplot(fig)

    st.subheader("Average Reach by Platform")

    avg_reach = df.groupby("Platform")["Reach"].mean()

    fig, ax = plt.subplots()
    avg_reach.plot(kind="bar", ax=ax)
    plt.ylabel("Average Reach")
    st.pyplot(fig)

    st.subheader("Top 10 Posts by Reach")

    top_posts = df.sort_values(by="Reach", ascending=False).head(10)

    st.dataframe(top_posts)

    st.success("Analysis Completed Successfully!")

else:
    st.info("Please upload your CSV dataset.")